/**
 * 
 */
/**
 * @author ELCOT
 *
 */
module FlightReservationSystem {
	requires java.sql;
}