package com.kce.service;

import com.kce.bean.BookingDetails;

public class Customer extends BookingDetails {
	public Customer(String name, int phNo, String flightName, int noOfSeats) {
		super(name, phNo, flightName, noOfSeats); 
		}
}
