package com.kce.Dao;

import com.kce.bean.FlightDetails;
import com.kce.util.DButil;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;
import java.util.Scanner;
class InvalidDateException extends Exception {
public InvalidDateException(String message) {
super(message);
}
}